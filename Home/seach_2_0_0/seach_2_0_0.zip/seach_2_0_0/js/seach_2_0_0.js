// const loadmore = document.querySelector('#loadmore');
// let currentItems = 6;
// loadmore.addEventListener('click', (e) => {
//     const elementList = [...document.querySelectorAll('.news_15_0_0__item')];
//     for (let i = currentItems; i < currentItems + 2; i++) {
//         if (elementList[i]) {
//             elementList[i].style.display = 'block';
//         }
//     }
//     currentItems += 2;

//     // Load more button will be hidden after list fully loaded
//     if (currentItems >= elementList.length) {
//         event.target.style.display = 'none';
//     }
// })

console.log(data);
const list = document.getElementById('list');
// console.log(list);
viewJob(data);

// View Job Function
function viewJob(data){
    for(let item of data){
        console.log(item);
        let position = item.position;
        let salary = item.salary;
        let place = item.place;
        let time = item.time;
        let amount = item.amount;
        let deadline = item.deadline;
        let link = item.link;
        list.innerHTML += `
            <div class="seach_2_0_0_mainBox">
                <div class="seach_2_0_0_mainItem col_1 seach_2_0_0_content">
                    <p><a href="${link}">${position}</a></p>
                </div>
                <div class="seach_2_0_0_mainItem col_2 seach_2_0_0_content">
                    <p>${salary}</p>
                </div>
                <div class="seach_2_0_0_mainItem col_3 seach_2_0_0_content">
                    <p>${place}</p>
                </div>
                <div class="seach_2_0_0_mainItem col_4 seach_2_0_0_content">
                    <p>${time}</p>
                </div>
                <div class="seach_2_0_0_mainItem col_5 seach_2_0_0_content">
                    <p>${amount}</p>
                </div>
                <div class="seach_2_0_0_mainItem col_6 seach_2_0_0_content">
                    ${deadline}
                    <p class="han_nop"><a href="${link}">xem chi tiết</a></p>
                </div>
            </div>
        `;
    }
}