const data = [
    {
        position: 'Nhân viên CPW',
        salary: '8-9 triệu',
        place:'Hà Nội',
        time: 'Fulltime',
        amount: '2 Người',
        deadline: '31/7/2021',
        link: '#1'
    },
    {
        position: 'Nhân viên CPW 2',
        salary: '8-9 triệu',
        place:'Hà Nội',
        time: 'Fulltime',
        amount: '2 Người',
        deadline: '31/7/2021',
        link: '#2'
    },
    {
        position: 'Nhân viên CPW 3',
        salary: '8-9 triệu',
        place:'Hà Nội',
        time: 'Fulltime',
        amount: '2 Người',
        deadline: '31/7/2021',
        link: '#3'
    },
    {
        position: 'Nhân viên CPW 3',
        salary: '8-9 triệu',
        place:'Hà Nội',
        time: 'Fulltime',
        amount: '2 Người',
        deadline: '31/7/2021',
        link: '#3'
    },
    {
        position: 'Nhân viên CPW 3',
        salary: '8-9 triệu',
        place:'Hà Nội',
        time: 'Fulltime',
        amount: '2 Người',
        deadline: '31/7/2021',
        link: '#3'
    },
    {
        position: 'Nhân viên CPW 3',
        salary: '8-9 triệu',
        place:'Hà Nội',
        time: 'Fulltime',
        amount: '2 Người',
        deadline: '31/7/2021',
        link: '#3'
    },
    {
        position: 'Nhân viên CPW 3',
        salary: '8-9 triệu',
        place:'Hà Nội',
        time: 'Fulltime',
        amount: '2 Người',
        deadline: '31/7/2021',
        link: '#3'
    },
    {
        position: 'Nhân viên CPW 3',
        salary: '8-9 triệu',
        place:'Hà Nội',
        time: 'Fulltime',
        amount: '2 Người',
        deadline: '31/7/2021',
        link: '#3'
    },
    {
        position: 'Nhân viên CPW 3',
        salary: '8-9 triệu',
        place:'Hà Nội',
        time: 'Fulltime',
        amount: '2 Người',
        deadline: '31/7/2021',
        link: '#3'
    },
    {
        position: 'Nhân viên CPW 3',
        salary: '8-9 triệu',
        place:'Hà Nội',
        time: 'Fulltime',
        amount: '2 Người',
        deadline: '31/7/2021',
        link: '#3'
    },
    {
        position: 'Nhân viên CPW 3',
        salary: '8-9 triệu',
        place:'Hà Nội',
        time: 'Fulltime',
        amount: '2 Người',
        deadline: '31/7/2021',
        link: '#3'
    },
    {
        position: 'Nhân viên CPW 3',
        salary: '8-9 triệu',
        place:'Hà Nội',
        time: 'Fulltime',
        amount: '2 Người',
        deadline: '31/7/2021',
        link: '#3'
    },
    {
        position: 'Nhân viên CPW 3',
        salary: '8-9 triệu',
        place:'Hà Nội',
        time: 'Fulltime',
        amount: '2 Người',
        deadline: '31/7/2021',
        link: '#3'
    },
]